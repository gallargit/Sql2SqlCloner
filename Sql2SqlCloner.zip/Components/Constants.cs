﻿namespace Sql2SqlCloner.Components
{
    public static class Constants
    {
        public const string ERROR = "ERROR";
        public const string OK = "OK";
        public const string WAITING = "WAITING";
        public const string WARNING = "WARNING";
    }
}
